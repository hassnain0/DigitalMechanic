export default{
   
    StartingLocation:require('../helpers/ImagePath'),
   
}