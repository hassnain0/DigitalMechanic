import React from 'react'
import { StyleSheet, View,Text } from 'react-native'

const ForgotScreen=()=>{
    return(
        <View>
            <Text>SignUp</Text>
        </View>
    )
}
const styles=StyleSheet.create({

})
export default ForgotScreen;